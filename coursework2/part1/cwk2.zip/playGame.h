void playGame( Game *game );

void showGame( Game *game );

int makeMove( Game *game, char symbol, int x, int y );

int inputHandler(int* x, int* y);

