
Game *initGame( int size, int length );
void createArray(Game *game);